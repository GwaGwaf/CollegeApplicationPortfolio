using Godot;
using System;

public partial class Enemy : Area2D
{
    #region Overrides
    public override void _Process(double delta)
    {
        Cooldown -= (float)delta;
        if (Cooldown < 0) Cooldown = 0;


        var randomValue = Random.Shared.Next(1000);
        if (randomValue < 15) Speed = Vector2.Left;
        else if (randomValue < 30) Speed = Vector2.Right;
        else if (randomValue < 35) Speed = Vector2.Up;
        else if (randomValue < 85) Speed = Vector2.Down;
        else Speed = Speed;
        Position += Speed*3;

        var enemySprite = GetNode<Sprite2D>("Sprite2D");
        var enemySize = enemySprite.Texture.GetSize() * enemySprite.Transform.Scale;

        
        if(Position.Y >  Main.Current.ScreenSize.Y)
        {
            QueueFree();
            Main.Current.GameOver();
        }
        
        Position = new Vector2(Mathf.Clamp(Position.X, 0, Main.Current.ScreenSize.X), Mathf.Clamp(Position.Y, 0, Main.Current.ScreenSize.Y));

        if (Random.Shared.Next(100) <= 15 && Cooldown <= 0)
        {
            var lazer = LazScene.Instantiate<Lazer>();
            var lazer2 = LazScene.Instantiate<Lazer>();
            var playerSprite = GetNode<Sprite2D>("Sprite2D");
            var playerSize = playerSprite.Texture.GetSize() * playerSprite.Transform.Scale;
            lazer.Position = Position;
            lazer.Init(new Vector2(Position.X + playerSize.X / 3.5F, Position.Y), false);
            AddSibling(lazer);
            lazer2.Init(new Vector2(Position.X - playerSize.X / 3.5F, Position.Y), false);
            AddSibling(lazer2);
            Cooldown = 5.0F;
            Main.Current.PlayLazerFireSound();
        }
    }
    #endregion

    #region Methods
    public void Init(Vector2 position)
    {
        Position = position;
        Speed = Vector2.Down;
        ZIndex = 2;
    }
    public void OnAreaEntered(Area2D other)
    {
        if (other.IsQueuedForDeletion()) return;
        if (other is Player)
        { 
            Main.Current.GameOver();
            Main.Current.PlayExplosionSound();
        }
        if (other is Enemy)
        {
            other.QueueFree();
            QueueFree();
            Main.Current.PlayExplosionSound();
        }
    }
    #endregion

    #region Properties
    public Vector2 Speed { get; set; }
    protected float Cooldown { get; set; }

    [Export] PackedScene LazScene { get; set; }
    #endregion
}
