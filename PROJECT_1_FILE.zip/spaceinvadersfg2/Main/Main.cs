using Godot;
using System;
using System.Reflection;
using System.Transactions;

public partial class Main : Node2D
{
    #region Overrides
    public override void _Ready() 
    {
        Current = this;
        Player = GetNode<Player>("PlayerArea2D");
        HUD = GetNode<HUD>("HudCanvasLayer");
        StartNewGame();
    }

    public override void _Process(double delta)
    {
        var random = Random.Shared.Next(250);
        if (random <= 1)
        {
            var enemy = EnemyScene.Instantiate<Enemy>();
            var enemySprite = enemy.GetNode<Sprite2D>("Sprite2D");
            var enemySize = enemySprite.Texture.GetSize() * enemySprite.Transform.Scale;
            enemy.Init(new Vector2(Random.Shared.NextSingle() * ScreenSize.X, 0));
            AddChild(enemy);
        }
        if (EnemyScene.Instantiate<Enemy>().Position.Y+200 >= ScreenSize.Y)
        {
            GameOver();
        }
    }
    #endregion
    
    #region Methods
    public void StartNewGame()
    {
        var playerSprite = Player.GetNode<Sprite2D>("Sprite2D");
        var playerSize = playerSprite.Texture.GetSize() * playerSprite.Transform.Scale;
        var x = ScreenSize.X / 2;
        var y = ScreenSize.Y - playerSize.Y;
        Player.Init(new Vector2(x, y));
    }
    public void GameOver()
    {
        HUD.Message.Text = "Game Over";
        Player.Visible = false;
    }
    public void PlayLazerFireSound()
    {
        GetNode<AudioStreamPlayer>("LazerFirePlayer").Play();
    }
    public void PlayExplosionSound()
    {
        GetNode<AudioStreamPlayer>("ExplosionPlayer").Play();
    }
    #endregion

    #region Properties
    public static Main Current { get; set; }
    public Vector2 ScreenSize => GetViewport().GetVisibleRect().Size;
    public Player Player { get; set; }
    [Export] PackedScene EnemyScene { get; set; }
    public HUD HUD { get; set; }
    #endregion
}
