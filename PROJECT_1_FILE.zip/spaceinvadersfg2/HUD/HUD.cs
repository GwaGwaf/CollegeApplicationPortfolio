using Godot;
using System;

public partial class HUD : CanvasLayer
{
    #region Overrides
    public override void _Ready()
    {
        Message = GetNode<Label>("MessageLabel");
    }
    #endregion

    #region Properties
    public Label Message { get; set; }
    #endregion
}
