using Godot;
using System;
using System.Reflection;

public partial class Lazer : Area2D
{
    #region Overrides
    public override void _Process(double delta)
    {
        var velocity = Direction * 1200;

        FlyTime += (float)delta;

        Position += velocity * (float)delta;
        if (Random.Shared.Next(-1, 1) == -1) { Position += Vector2.Left * 200 * (float)delta; }
        else { Position += Vector2.Right * 200 * (float)delta; }
        if (Position.Y > GetViewport().GetVisibleRect().Size.Y || Position.Y < 0)
        {
            QueueFree();
        }

    }
    #endregion

    #region Methods
    public void Init(Vector2 position, bool isGoingUp = true)
    {
        Position = position;
        ZIndex = 1;
        if (isGoingUp)
        {
            Direction = Vector2.Up;
        }
        else
        {
            Direction = Vector2.Down;
            Rotation += MathF.PI;
        }
    }
    public void OnAreaEntered(Area2D other)
    {
        if (FlyTime < 0.1) return;
        else
        {
            if (other.IsQueuedForDeletion()) return;
            if (other is Player) Main.Current.GameOver();
            Main.Current.PlayExplosionSound();
            other.QueueFree();
            QueueFree();
        }
    }
    #endregion

    #region Properties
    public Vector2 Direction { get; protected set; }
    public float FlyTime { get; set; }
    #endregion

}