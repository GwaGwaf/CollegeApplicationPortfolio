using Godot;
using System;

public partial class Player : Area2D
{
    #region Overrides
    public override void _Process(double delta)
    {
        Cooldown -= (float)delta;
        if (Cooldown < 0) Cooldown = 0;
        const float speedPerSecond = 750;
        if (Input.IsActionPressed("Left")) Position -= new Vector2(speedPerSecond * (float)delta, 0);
        if (Input.IsActionPressed("Right")) Position += new Vector2(speedPerSecond * (float)delta, 0);
        var screenSize = GetViewport().GetVisibleRect().Size;
        Position = new Vector2(Mathf.Clamp(Position.X, 0, screenSize.X), Mathf.Clamp(Position.Y, screenSize.Y - 100, screenSize.Y));
        if (Input.IsActionJustPressed("Space") && Cooldown <= 0)
        {
            var lazer = LazScene.Instantiate<Lazer>();
            var lazer2 = LazScene.Instantiate<Lazer>();
            var playerSprite = GetNode<Sprite2D>("Sprite2D");
            var playerSize = playerSprite.Texture.GetSize() * playerSprite.Transform.Scale;
            lazer.Position = Position;
            lazer.Init(new Vector2(Position.X + playerSize.X / 3.5F, Position.Y), true);
            AddSibling(lazer);
            lazer2.Init(new Vector2(Position.X - playerSize.X / 3.5F, Position.Y), true);
            AddSibling(lazer2);
            Cooldown = 0.3F;
            Main.Current.PlayLazerFireSound();
        }
    }
    #endregion

    #region Methods
    public void Init(Vector2 position)
    {
        Position = position;
        ZIndex = 2;
    }
    #endregion

    #region Properties
    public Vector2 Size { get; protected set; }
    protected float Cooldown { get; set; }

    [Export] PackedScene LazScene { get; set; }
    //[Export] PackedScene LazerScene { get; set; }
    #endregion
}
